 
//put your javascript code below



function actionHtmlWindow(str) {
	new ActionHtmlWindow(str);
}
